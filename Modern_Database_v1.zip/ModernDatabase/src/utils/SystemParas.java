package utils;

/**
 * 系统配置参数加载类
 * 
 * @author kernal
 * 
 */
public class SystemParas {
	public static String dll_or_so_lib_path = ReadConfigUtil.getValue("dll_or_so_path");
}
