package modern;

import java.net.*;

/**
 * @author kslim1025
 *
 */
public class xikaoDAO {
	URL url;
	String name;
	String birth; 
	String death;
	String classfication;
	String introduce;
	
	public xikaoDAO(URL url, String name, String birth, String death, String classfication, String introduce){
		super();
		this.url= url;
		this.name= name;
		this.birth= birth;
		this.death= death;
		this.classfication= classfication;
		this.introduce= introduce;
	}

	public URL getUrl() {
		return url;
	}

	public void setUrl(URL url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getDeath() {
		return death;
	}

	public void setDeath(String death) {
		this.death = death;
	}

	public String getClassfication() {
		return classfication;
	}

	public void setClassfication(String classfication) {
		this.classfication = classfication;
	}

	public String getIntroduce() {
		return introduce;
	}

	public void setIntroduce(String introduce) {
		this.introduce = introduce;
	}
	public void display() {
		System.out.printf("get name : %s",getName());
	}
}
