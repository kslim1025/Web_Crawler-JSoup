package modern;

import java.util.ArrayList;

public class Dictionary <S, T> {

	protected ArrayList<String> keyList = new ArrayList<> ();
	protected ArrayList<T> valueList = new ArrayList<> ();
	public int count = 0;
	
	public void add (String key, T value) {
		if (!(keyList.contains(key))) {
			keyList.add(key);
			valueList.add(value);
			count = keyList.size();
		} else {
			System.out.println("This key is already exist");
		}
	}
	
	public void remove (String key) {
		if (keyList.contains(key)) {
			int index = keyList.indexOf(key);
			keyList.remove(index);
			valueList.remove(index);
			count = keyList.size();
		} else {
			System.out.println("This key doesn't exist");
		}
	}
	
	public void removeAt (int index) {
		if (keyList.get(index) != null) {
			keyList.remove(index);
			valueList.remove(index);
			count = keyList.size();
		} else {
			System.out.println("This key doesn't exist");
		}
	}
	
	public boolean containsKey (String key) {
		if (keyList.contains(key)) { return true; } 
		else { return false; }
	}
	
	public boolean containsValue (T value) {
		if (valueList.contains(value)) { return true; } 
		else { return false; }
	}
	
	public boolean isEmpty () {
		if (keyList.size() <= 0) { return true; } 
		else { return false; }
	}
	
	public T get (String key) {
		if (keyList.contains(key)) { 
			int index = keyList.indexOf(key);
			return valueList.get(index);
		} else { 
			System.out.println("This key doesn't exist");
			return null;
		}
	}
	
	public T set (String key, T value) {
		if (keyList.contains(key)) { 
			int index = keyList.indexOf(key);
			return valueList.set(index, value);
		} else { 
			System.out.println("This key doesn't exist");
			return null;
		}
	}
	
	public void clear () {
		keyList.clear ();
		valueList.clear ();
		count = keyList.size();
	}
	
	public void display () {
		if (!isEmpty()) {
			for (int i = 0; i < count; i++) {
				System.out.println(keyList.get(i) + ": " + valueList.get(i));
			}
		}
	}
}
