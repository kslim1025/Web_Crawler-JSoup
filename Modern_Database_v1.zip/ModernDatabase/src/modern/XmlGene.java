package modern;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;

import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.w3c.dom.Text;
import org.xml.sax.*;

import modern.*;

import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class XmlGene {
 /**
  * @param args
  */
	public XmlGene() {
        try {
            xikaoXml();
            } 
        catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            }
	}
       
	private void xikaoXml() throws Exception{

	//	SAXBuilder b = new SAXBuilder();  // true -> validate  
		
		Scanner scan = null;  
		
	//	Document doc = b.build(new File("./src/FinalResult.xml"));  

		Document doc=new Document();
		  try {      

				  scan = new Scanner(new File("./src/info.txt"));
				//  Thread.sleep(1000); 
				  //package-name element 에 value 값을 text 로 넣어 주기
				  Element root = new Element("generator");
				  Element pack = new Element("package");
				  root.addContent(pack);//root element 의 하위 element 를 만들기; 
				  doc.setRootElement(root);
				 for(int g=0; g<1005;g++){
			//	  Thread.sleep(100); 
				 // System.out.println("<1>"+scan.nextLine()+"</pack_name>");
				  Element pack_n = new Element("pack_name");
				  Element url = new Element("url");
				  Element name = new Element("name");
				  Element birthday = new Element("birthday");
				  Element death = new Element("death");
				  Element classfication = new Element("classfication");					  
				  Element introduce = new Element("introduce");
				  
                  if(g==0){
				  pack.addContent(pack_n); //package element 의 하위로 package-name 만들기				  
				  pack_n.setText("xikaojingyuan");
				  System.out.println("<pack_name>"+"xikaojingyuan"+"<pack_name>");  			  
				  pack_n.setAttribute("xikaojingyuan", String.valueOf((g)));
                  }
                  
               //   Thread.sleep(1000); 
				/*  String j = scan.nextLine();
				  System.out.println(j);
                  String k= "URL";
                  if(j.equals(k))
                  {*/
                  String j = scan.nextLine();
				  pack.addContent(url);
				  url.setText(j);
				  System.out.println("<url>"+j+"</url>");
				  url.setAttribute("url", String.valueOf(g));				  
               //   }
                  
               /*   Thread.sleep(1000); 
                  String l = scan.nextLine();
                  System.out.println(l);
                  String m= "姓名";
                  if(l.equals(m))
                  {*/
				  String l = scan.nextLine();
				  pack.addContent(name);
				  name.setText(l);
				  System.out.println("<name>"+l+"</name>");
				  name.setAttribute("name", String.valueOf(g));
                 // }
                /*  Thread.sleep(1000); 
                  String n = scan.nextLine();
                  System.out.println(n);
                  String o= "出生";
                  if(n.equals(o))
                  {*/
				  String n = scan.nextLine();
			      pack.addContent(birthday);
				  birthday.setText(n);
				  System.out.println("<birthday>"+n+"</birthday>");
				  birthday.setAttribute("birthday", String.valueOf(g));
                 // }
                  
                 /* Thread.sleep(1000); 
                  String p = scan.nextLine();
                  System.out.println(p);
                  String q= "逝世";
                  if(p.equals(q))
                  {*/
				  String p = scan.nextLine();
				  pack.addContent(death);
				  death.setText(p);
				  System.out.println("<death>"+p+"</death>");
				  death.setAttribute("death", String.valueOf(g));
                 // }
                  
                 /* Thread.sleep(1000); 
                  String s = scan.nextLine();
				  System.out.println(s);
                  String t= "行当";
                  if(s.equals(t))
                  {*/
				  String s = scan.nextLine();
				  pack.addContent(classfication);
				  classfication.setText(s);
				  System.out.println("<classfication>"+s+"</classfication>");
				  classfication.setAttribute("classfication", String.valueOf(g));
                  //}
                  
                 /* Thread.sleep(1000); 
                  String u = scan.nextLine();
                  System.out.println(u);
                  String v= "详细资料当";
                  if(u.equals(v))
                  {*/
				  String u = scan.nextLine();
				  pack.addContent(introduce);
				  introduce.setText(u);
				  System.out.println("<introduce>"+u+"</introduce>");
				  introduce.setAttribute("introduce", String.valueOf(g));
                 // }
               //   Thread.sleep(1000); 
				 }
		  }
		  catch (IOException e) 
		  {                                         
		      System.err.println(e);                                        
		  }    
		  finally{
			  try 
              {
				//  Thread.sleep(1000); 
					 FileOutputStream out = new FileOutputStream("./src/FinalResult.xml"); 
				      //xml 파일을 떨구기 위한 경로와 파일 이름 지정해 주기
				      XMLOutputter serializer = new XMLOutputter();                 
					 
				      //<?xml-stylesheet type="Text/xsl" href="PCTExmnSrh_6.xsl"?>            
				      Map<String, String> m = new HashMap<String, String>(); 
				      m.put("href", "PCTExmnSrh_6.xsl"); 
				      m.put("type", "Text/xsl"); 
				      doc.addContent(0, new ProcessingInstruction("xml-stylesheet", m));

				      Format f = serializer.getFormat();                            
				      f.setEncoding("UTF-8");
				      //encoding 타입을 UTF-8 로 설정
				      f.setIndent(" ");                                             
				      f.setLineSeparator("\r\n");                                   
				      f.setTextMode(Format.TextMode.TRIM);                          
				      serializer.setFormat(f);       
				      serializer.output(doc, out);    
				      out.flush();                                                  
					  out.close();         
              } 
              catch (Exception e) 
              {
              	
              }
		 }
	  }
	public static void main(String[] args) {
	   //   new xikao(); //877 list
	   //	new crowler(); //123 list
	    new XmlGene(); //make a xml file
		}
}
