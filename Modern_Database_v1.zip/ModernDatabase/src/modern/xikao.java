package modern;

import java.io.*;
import java.net.*;
import java.util.*;

import org.jdom.output.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import modern.*;

 
public class xikao{
      BufferedInputStream bis = null;
      BufferedReader reader = null;
      HttpURLConnection conn = null;
      xikaoDAO[] xika = new xikaoDAO[1000];
      
    public xikao() {
        try {
          //  urlList();
            xikaoValue();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    private void urlList() throws Exception {
    	//xikao URL list 877
        URL url = new URL("http://history.xikao.com/directory/%E4%BA%AC%E5%89%A7/%E7%94%9F%E8%A1%8C%E6%BC%94%E5%91%98");
        try {
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty(
                    "user-agent",
                    "Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) "
                   + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2307.2 Mobile Safari/537.36");
            conn.setRequestProperty("Accept","text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
            conn.connect();
            conn.setInstanceFollowRedirects(true);
            
            bis = new BufferedInputStream(conn.getInputStream());
            reader = new BufferedReader(new InputStreamReader(bis));
            
            StringBuffer st = new StringBuffer();
            String line;
            Storage<String> storage =new Storage<>();
            
            while ((line = reader.readLine()) != null) 
            {
                st.append(line + "\n");
            }
 
            Document doc = Jsoup.parse(st.toString());
            Elements name = doc.select("li");
            Elements div = name.select(".exist");
            System.out.println("Start parse");
          
            for(Element e : div){
            	System.out.println("http://history.xikao.com"+e.attr("href"));
            }
                storage.Write("./src/","Result",div.toString());
        } 
        finally 
        {
            try 
            {
                bis.close();
                reader.close();
                conn.disconnect();
            } 
            catch (Exception e) 
            {
            	
            }
        	}
        }
    
    @SuppressWarnings("resource")
	private void xikaoValue() throws Exception 
    {
    	Scanner scan = null;  
        scan = new Scanner(new File("./src/Result.txt")); 
        for(int i=0; i<877;i++){
            try {
            	String name = null;
            	String birth = null;
            	String death = null;
            	String classfication = null;
            	String introduce = null;
            	
            	String str = scan.nextLine();
                //URL url = new URL("http://history.xikao.com/person/%E5%AE%89%E8%88%92%E5%85%83");
            	URL url = new URL(str);
          	    System.out.println("URL : "+url);
            	conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                conn.setInstanceFollowRedirects(true);
                bis = new BufferedInputStream(conn.getInputStream());
                reader = new BufferedReader(new InputStreamReader(bis));
                
                StringBuffer st = new StringBuffer();
                String line;
                
                while ((line = reader.readLine()) != null) 
                {
                   st.append(line + "\n");
                   continue;
                }
                
                Document doc = Jsoup.parse(st.toString());
                Elements di = doc.select("div .photoHolder");
                //System.out.println(di);
                for (Element e : di) 
                  {
                   System.out.println("姓名："+e.select("div .caption").text());
                   name=e.select("div .caption").text();
                   String birthday = e.select("font.birth").text();
                   String hanzi_birthday= "出生";
                   if(birthday.equals(hanzi_birthday)){
                 	  // System.out.println("0");
                 	  System.out.println(e.select(".birth").text()+":"+e.select("a[href]").get(0).text());
                 	  birth=e.select(".birth").text()+":"+e.select("a[href]").get(0).text();
                   }
                    else{
                 	   System.out.println("出生：");
                    }
                   
                   String s = e.select(".death").text();
                   String b= "逝世";
                   if(s.equals(b)){
                	  // System.out.println("0");
                	  System.out.println(e.select(".death").text()+":"+e.select("a[href]").get(1).text());
                	  death=e.select(".death").text()+":"+e.select("a[href]").get(1).text();
                  }
                   else{
                	   System.out.println("逝世：");
                   }
                	String d="生行演员";
                	String f=e.select("a[href]").get(3).text();
                	classfication=e.select("a[href]").get(3).text();
                	if(d.equals(f)){
                		System.out.println("行当"+":"+e.select("a[href]").get(3).text());
                	}
                	else{
                		System.out.println("行当"+":京剧老生");
                	}
                	
                }
                Document doca = Jsoup.parse(st.toString());
                Elements dic = doca.select("table");
                for (Element f : dic) 
                  {
                	String h=f.select("tr").text();
                	introduce=f.select("tr").text();
                	
                    if(h!=null){
                	System.out.println("详细资料: "+f.select("tr").text());
                	//introduce=f.select("tr").text();
                    }
                    else if(h==null){
                    	System.out.println("详细资料: ");
                    }
                  }
                xikaoDAO xika = new xikaoDAO(url, name, birth,death, classfication, introduce);
                System.out.println(xika.getUrl()+xika.getName()+xika.getBirth()+xika.getDeath()+xika.getClassfication()+xika.getIntroduce());
              //  storage.Write("./src/","info",di.toString());
               
                } 
            catch (Exception e1) 
                {
            	//System.out.println(e1);
                }
            finally
            {
            	try 
                {
                    bis.close();
                    reader.close();
                    conn.disconnect();
                } 
                catch (Exception e) 
                {
                	
                }
            }
          }
        } 
	public static void main(String[] args) {
   //   new xikao(); //877 list
   	new crowler(); //123 list
	}
  }