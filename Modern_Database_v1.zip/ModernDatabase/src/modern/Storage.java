package modern;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/*
It must needs Dictionary, if you don't have, 
	please visit my Web Site (http://blog.naver.com/2983934/221105939445)
And you need to change access modifier of ketList, valueList in Dictionary class
You can make Storage<Type> instance to use it
If you input Dictionary instead of String, it will write with converting it to text
	or it will read on it with converting text to Dictionary
When using it with Dictionary, you must keep the rule for use it
	1. text contents must include ":" and ","
	2. value must exist just one
	3. do not use blank
	example) HP:150,SP:300,MP:100, => HP,SP,MP is key, 150,300,100 is value
*/

public class Storage<T> extends Dictionary<String, T> {
	
	//Write with String
	public void Write (String path, String name, String input) {
		try {
			File file = new File(path + name + ".txt");
			FileWriter FW = new FileWriter(file, false);
			BufferedWriter BW = new BufferedWriter (FW);
			BW.write(input);
			BW.flush();
			
			if (FW != null) FW.close();
			if (BW != null) BW.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	//Write with Dictionary<String, T>
	public void Write (String path, String name, Dictionary<String, T> dictionary) {
		try {
			File file = new File(path + name + ".txt");
			FileWriter FW = new FileWriter(file, false);
			BufferedWriter BW = new BufferedWriter (FW);
			StringBuilder SB = new StringBuilder ();
			for (int i = 0; i < dictionary.count; i ++) {
				SB.append(dictionary.keyList.get(i) + ":");
				SB.append(dictionary.valueList.get(i) + ",");
			}
			BW.write(SB.toString());
			BW.flush();
			
			if (FW != null) FW.close();
			if (BW != null) BW.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	//Load on String
	public String Read (String path, String name) {
		StringBuilder SB = new StringBuilder ();
		try {
			File file = new File(path + name + ".txt");
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader (FR);
			String output = "";
			
			while ((output = BR.readLine()) != null) {
				SB.append(output);
				SB.append("\n");
			}
			
			if (FR != null) FR.close();
			if (BR != null) BR.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return SB.toString();
	}
	//Load on Dictionary<String, T>
	@SuppressWarnings("unchecked")
	public void Read (String path, String name, Dictionary<String, T> dictionary) {
		try {
			File file = new File(path + name + ".txt");
			FileReader FR = new FileReader(file);
			BufferedReader BR = new BufferedReader (FR);
			String output = null;
			
			while ((output = BR.readLine()) != null) {
				String[] outputs = output.split(",");
				for (String string : outputs) {
					String[] s = string.split(":");
					dictionary.add(s[0], (T)s[1]);
				}
			}
			
			if (FR != null) FR.close();
			if (BR != null) BR.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
