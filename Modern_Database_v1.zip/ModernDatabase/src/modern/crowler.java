package modern;

import org.jsoup.nodes.Document;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import modern.Storage;

public class crowler{
 
    public crowler() {
        try {
            cdcNotice();
            } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
 
    private void cdcNotice() throws Exception {
        BufferedInputStream bis = null;
        BufferedReader reader = null;
        HttpURLConnection conn = null;
        
        
        for(int i=2;i<84;i++)
        {
            Document doc = Jsoup.connect("http://www.jingju.com/jingjurenwu/yuantuanmingjia/index_"+i+".html").get();
            Elements name = doc.select(".RWlist .c963");
           
            for (Element e : name) {
            	System.out.println("URL : "+"http://www.jingju.com/"+e.getElementsByAttribute("href").attr("href"));
            try {
            	Document doc2 = Jsoup.connect("http://www.jingju.com/"+e.getElementsByAttribute("href").attr("href")).get();
            //	System.out.println(doc2);
            	Elements name1 = doc2.select("div .Rnamer");
            //	System.out.println(name1);
            for (Element e1 : name1) {
            	System.out.println(e1.text());
            	//System.out.println(e1.getElementsByAttribute("[label]"));
                }
            //	ArrayList<String> list= new ArrayList();
            //	list.add(e.getElementsByAttribute("href").attr("href"));
            //	storage.Write("./src/","jingju","http://www.jingju.com/"+list.toString());
                bis.close();
                reader.close();
                conn.disconnect();   	
 
            } catch (Exception e1) 
            {
            	//System.out.println(e1);
            }
        	}
        }
    }

}