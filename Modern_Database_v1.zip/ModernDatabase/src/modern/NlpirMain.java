package modern;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

import com.sun.jna.Library;
import com.sun.jna.Native;
/**
 * ��ȡʵ����
 * @author Administrator
 *
 */
public class NlpirMain {
	
	// ����ӿ�CLibrary���̳���com.sun.jna.Library
	public interface CLibrary extends Library {
		
		// ���岢��ʼ���ӿڵľ�̬����
		CLibrary Instance = (CLibrary) Native.loadLibrary("lib/libNLPIR.dylib", CLibrary.class);
		
		public int NLPIR_Init(String sDataPath, int encoding,
				String sLicenceCode);
				
		public String NLPIR_ParagraphProcess(String sSrc, int bPOSTagged);

		public String NLPIR_GetKeyWords(String sLine, int nMaxKeyLimit,
				boolean bWeightOut);
		public String NLPIR_GetFileKeyWords(String sLine, int nMaxKeyLimit,
				boolean bWeightOut);
		public int NLPIR_AddUserWord(String sWord);
		public int NLPIR_DelUsrWord(String sWord);
		public String NLPIR_GetLastErrorMsg();
		public void NLPIR_Exit();
	}

	public static String transString(String aidString, String ori_encoding,
			String new_encoding) {
		try {
			return new String(aidString.getBytes(ori_encoding), new_encoding);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void main(String[] args) throws Exception {
		
		String argu = "";
		int charset_type = 1;
		
		int init_flag = CLibrary.Instance.NLPIR_Init(argu, charset_type, "0");
		String nativeBytes = null;

		if (0 == init_flag) {
			nativeBytes = CLibrary.Instance.NLPIR_GetLastErrorMsg();
			System.err.println("fail reason is "+nativeBytes);
			return;
		}

		try {
			
			String filename="FinalResult.xml";
			
			xikaoDAO[] newsarray=new xikaoDAO[100];
			String[] peopleRes=new String[100];
			String[] placeRes=new String[100];
			
			for(int i=0;i<100;i++){

				peopleRes[i]=extractInfo(nativeBytes,"/nr");
				placeRes[i]=extractInfo(nativeBytes,"/ns");
				
				System.out.println("peopleRes[i]"+peopleRes[i]);
				System.out.println("placeRes[i]"+placeRes[i]);
			}
			
			CLibrary.Instance.NLPIR_Exit();
			
		} catch (Exception ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}

	}
	 private static String extractInfo(String nlpirStr, String cueStr) {
		
		 String resStr="";
		 String[] temparray=null;
		 HashMap<String,Integer> hm = new HashMap<String,Integer>();
		 
		 temparray=nlpirStr.split(" ");
		 for(int i=0;i<temparray.length;i++){
			 if(temparray[i].contains(cueStr)){
				 int index=temparray[i].indexOf(cueStr);
				 String temp=temparray[i].substring(0,index);
				 if(hm.containsKey(temp)){
					 int count=hm.get(temp);
					 hm.put(temp, count+1);
					 
				 }
				 else
					 hm.put(temp, 1);
			}
		 }
		 
		 Iterator<Entry<String, Integer>> it = hm.entrySet().iterator() ;
		 while (it.hasNext())
		 {
			 Map.Entry<String,Integer> entry = it.next() ;
			 String key = (String) entry.getKey() ;
			 Integer value = (Integer) entry.getValue() ;
			 resStr=resStr+key+"("+value+") ";
		 } 

		 return resStr;
	}
}